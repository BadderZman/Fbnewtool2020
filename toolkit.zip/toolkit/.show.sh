clear
echo
echo
echo -e "\e[1;31m"
figlet MENU
echo -e "\e[1;34m Created By \e[1;32m"
toilet -f mono12 -F border B.C.M
echo -e "\e[4;34m This TOOL Was Created By LEGENDS AND CRIMINALS \e[0m"
echo -e "\e[1;34m For Any Queries Mail Me!!!\e[0m"
echo -e "\e[1;32m           Mail: legends.and.criminals@gmail.com \e[0m"
echo -e "\e[4;32m        FB Page: https://www.facebook.com/c/labibmirza11 \e[0m"
echo " "
echo -e "\e[4;31m Please Read Instruction Carefully !!! \e[0m"
echo " "
echo "----------------------------------- "
echo "|1. Darkfb version 1.4             | "
echo "|----------------------------------| "
echo "|2. Darkfb version 1.5             | "
echo "|----------------------------------| "
echo "|3. Darkfb version 1.6             | "
echo "|----------------------------------| "
echo "|4. Darkfb version 1.7             | "
echo "|----------------------------------| "
echo "|5. Darkfb version 1.8             | "
echo "|----------------------------------| "
echo "|6. Darkfb version 1.9             | "
echo "|----------------------------------| "
echo "|7. Darkfb version VIP             | "
echo "|----------------------------------| "
echo "|8. Darkfb version VIP 2           | "
echo "|----------------------------------| "
echo "|9. Menu2                          | "
echo "|----------------------------------| "
read ch
if [ $ch -eq 1 ];then
clear
echo -e "\e[1;32m"
cd .repos
python2 v4.py
exit 0
elif [ $ch -eq 2 ];then
clear
echo -e "\e[1;32m"
echo 'Lac'
cd .repos
python2 v5.py
exit 0
elif [ $ch -eq 3 ];then
clear
cd .repos
python2 v6.py
exit 0
elif [ $ch -eq 4 ];then
cd .repos
python2 v7.py
exit 0
elif [ $ch -eq 5 ];then
clear
cd .repos
python2 v8.py
exit 0
elif [ $ch -eq 6 ];then
clear
cd .repos
python2 v9.py
exit 0
elif [ $ch -eq 7 ];then
clear
cd .repos
python2 vip1.py
exit 0
elif [ $ch -eq 8 ];then
clear
cd .repos
python2 vip2.py
exit 0
elif [ $ch -eq 9 ];then
clear
bash .show2.sh
exit 0
elif [ $ch -eq 10 ];then
clear
echo -e "\e[1;31m"
figlet FB TOOL
echo -e "\e[1;34m Created By \e[1;32m"
toilet -f mono12 -F border B.C.M
echo -e "\e[1;34m For Any Queries Mail Me!!!\e[0m"
echo -e "\e[1;32m           Mail: legends.and.criminals@gmail.com \e[0m"
echo -e "\e[1;32m       Facebook: https://m.facebook.com/labibmirza11 \e[0m"
echo -e "\e[4;32m   Special Thanks To Labib \e[0m"
echo " "
exit 0
else
echo -e "\e[4;32m Invalid Input !!! \e[0m"
echo "Press Enter To Go Home"
read a3
clear
fi
done